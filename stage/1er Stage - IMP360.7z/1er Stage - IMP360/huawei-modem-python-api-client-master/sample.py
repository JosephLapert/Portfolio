from pprint import pprint

from huaweisms.api import monitoring, sms, user
from huaweisms.api.common import ApiCtx


USER = "DICOMSOFT"
PASSWORD = "dicomsoft"
PHONE_NUMBER = "+33651053865"

# BEFORE running, do MAKE SURE heaweisms.api.config has the CORRECT VALUES for your MODEM


def get_session():
    return user.quick_login(USER, PASSWORD)


def valid_context(ctx):
    # type: (ApiCtx) -> bool
    sl = user.state_login(ctx)
    if sl["type"] == "response" and sl["response"]["State"] != -1:
        return True
    return False


ctx = get_session()
sent = sms.send_sms(ctx, PHONE_NUMBER, "This is a test")
pprint(sent)
status = monitoring.status(ctx)
pprint(status)
