import sys       # importe le sys pour utiliser les argv

from huaweisms.api import sms, user         # importation des librairies de l'api et des fichiers sms user
from huaweisms.api.common import ApiCtx     # importation du fichier common et de ApiCtx


USER = "admin"                              # nom d'utilisateur
PASSWORD = "xxxxxxxxxxx"                    # Mot de passe de connexion
PHONE_NUMBER = "xxxxxxxxxx"                 # Numéro de téléphone


def get_session():                                  # Fonction qui permet de se connecter en retournant le quick login
    return user.quick_login(USER, PASSWORD)

def valid_context(ctx):                             
    # type: (ApiCtx) -> ...
    sl = user.state_login(ctx)
    if sl["type"] == "response" and sl["response"]["State"] != -1:
        return True
    return False

def disconnect_mobile(ctx):                         
    # type: (ApiCtx) -> ...
    print("test", ctx)


if __name__ == "__main__":                                                              # Fonction main pour lancer un script avec la cmd
    # USAGE: python3 sendmsg.py <password> <number> <message>
    # Arguments are <program> <password> <to_phone> <message>
    if len(sys.argv) != 4:                                                              # Fonction If pour connaitre le nombre d'argument ici 4
        print("Incomplete arguments ", len(sys.argv) - 1, "received, 3 required")       # affiche les arguments requis pour len(sys.argv != 4)
        print("USAGE:", sys.argv[0], '"admin password" "phone number" "message"')       # affiche les 3 arguments lors de la saisie des arguments
        exit()
                                                                                        
                                                                                           
                                                                                        # sys.argv[0] est le nom du fichier                                
    PASSWORD = sys.argv[1]                                                              # password définit à sys.argv[1]
    PHONE_NUMBER = sys.argv[2]                                                          # phone_number définit à sys.argv[2]
    MESSAGE = sys.argv[3]                                                               # message définit à sys.argv[3]

    ctx = get_session()                                                                 # fonction qui permet de quick_login
    sent = sms.send_sms(ctx, PHONE_NUMBER, MESSAGE)                                     # attribution de la variable sent

    if sent["type"] == "response" and sent["response"] == "OK":                         # Message de vérification de l'envoi du sms
        print("Message sent.")
        disconnect_mobile("variable")
    else:
        print("Message error")

