from faker.factory import Factory
from faker.generator import Generator
from faker.proxy import Faker

VERSION = '8.10.3'

__all__ = ('Factory', 'Generator', 'Faker')
