import sys
import subprocess
from pprint import pprint

from huaweisms.api import webserver, device, monitoring, user, sms, ussd
from huaweisms.api.common import ApiCtx

USER="admin"
PASSWORD="N40YYY1NB1R"

def get_session():
    ctx = ApiCtx()
    token = webserver.SesTokInfo()
    ctx.session_id = token['response']['SesInfo'].split("=")[1]
    ctx.token = token['response']['TokInfo']
    lgn = user.login(ctx, USER, PASSWORD)
    #pprint(lgn)
    return ctx

ctx = get_session()

inbox = 1 
outbox = 2
page =1 
howmany = 20 

# Delete all the previously sent messages first
msgs = sms.get_sms(ctx,outbox,page,howmany)
nummsgs = int(msgs['response']['Count'])
if nummsgs > 0:
   for k in range(0,nummsgs):
      idx=int(msgs['response']['Messages']['Message'][k]['Index'])
      res=sms.delete_sms(ctx,idx)


#Now get the new ones
msgs = sms.get_sms(ctx,inbox,page,howmany)
nummsgs = int(msgs['response']['Count'])

if nummsgs > 0:
   for k in range(0,nummsgs):
      idx=int(msgs['response']['Messages']['Message'][k]['Index'])
      content=str(msgs['response']['Messages']['Message'][k]['Content'])
      num=str(msgs['response']['Messages']['Message'][k]['Phone'])
      print("Msg from" + num + " msg=" + content)

      #if the message starts with cmd: then it is a command...
      if content.lower().startswith("cmd:"):
         print("command")
         
         #establish the VPN?
         if content.lower().startswith("cmd:pptp on") \
                 or content.lower().startswith("cmd:vpn on"):
            output = subprocess.run("sudo pon PPTP_VPN", shell=True, stdout=subprocess.PIPE, universal_newlines=True)
            print(output.stdout)
            sent = sms.send_sms(ctx, num, "tried to start VPN")
            print("pptp on received")

         #turn off the VPN?
         elif content.lower().startswith("cmd:pptp off") \
                or content.lower().startswith("cmd:vpn off"):
            output = subprocess.run("sudo poff PPTP_VPN", shell=True, stdout=subprocess.PIPE, universal_newlines=True)
            print(output.stdout)
            sent = sms.send_sms(ctx, num, "tried to stop VPN")
            print("pptp off received")

         #Reboot the Pi
         elif content.lower().startswith("cmd:reboot"):
            sent = sms.send_sms(ctx, num, "Reboot command received")
            print("Reboot received")
            output = subprocess.run("sudo reboot", shell=True, stdout=subprocess.PIPE, universal_newlines=True)
            print(output.stdout)

         #Take a picture adn upload it to Dropbox
         elif content.lower().startswith("cmd:picture"):
            output = subprocess.run("python3 /home/pi/camera/uploader.py", shell=True, stdout=subprocess.PIPE, universal_newlines=True)
            sent = sms.send_sms(ctx, num, "Picture uploaded.")

         #respond with a generic message to know that something was received...
         else:
            sent = sms.send_sms(ctx, num, "pong - " + content)

      #if the message contains the word weather...
      elif content.lower().rfind("weather")!=-1:
         print("weather request received")
         with open("/var/www/html/weewx/SMS") as f:
            file_content = f.read().rstrip("\n")
            f.close()
         sent = sms.send_sms(ctx, num, file_content)

      #a message with no command nor weather was received.
      else:
         print("unknown message received")
         sent = sms.send_sms(ctx, num, "Hi from Beaverstone Bay! Ask me about the Weather!")


      #delete the message we just received
      res=sms.delete_sms(ctx,idx)